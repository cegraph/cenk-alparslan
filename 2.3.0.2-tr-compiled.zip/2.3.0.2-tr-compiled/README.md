# OpenCart Türkçe

## Genel Bakış

OpenCart PHP tabanlı açık kaynak kodlu online alışveriş sepetidir. Tüccarların düşük bir maliyet ile kendi e-ticaret mağazalarını oluşturmada yardımcı olan güçlü bir e-ticaret yazılımıdır.

## Güncelleme

[Güncelleme Dokümanı] (http://weblenti.com/how-to-opencart-upgrade)

## Türkçe Destek

[Resmi Türkçe Destek Forumu] (http://forum.opencart.com/viewforum.php?f=171)

## Lisans

[GNU General Public License version 3 (GPLv3)](https://github.com/epiksel/opencart-tr/blob/master/lisans.txt)

## Türkçe Çeviri

[opencart-tr Opencart Türkiye] (http://opencart-tr.com)
