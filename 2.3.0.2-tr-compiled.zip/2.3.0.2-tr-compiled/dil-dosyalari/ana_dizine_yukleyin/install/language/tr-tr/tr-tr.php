<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Buttons
$_['button_continue'] = 'Devam Et';
$_['button_back']     = 'Geri';

// Error
$_['error_exception'] = 'Hata Kodu(%s): %s in %s on line %s';