<?php
/* Turkceye Ceviren eka7a - http://opencart-tr.com */

$_['text_project']       = 'Proje Anasayfa';
$_['text_documentation'] = 'Dökümanlar';
$_['text_support']       = 'Destek Forumları';
$_['text_footer']        = 'Copyright © 2014 OpenCart Türkçe - Tüm hakları saklıdır.';