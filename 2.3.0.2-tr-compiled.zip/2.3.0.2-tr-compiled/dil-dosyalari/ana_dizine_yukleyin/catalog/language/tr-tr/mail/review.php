<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_subject']  = '%s - Ürüne Yorum Yapıldı';
$_['text_waiting']  = 'Onay bekleyen yeni bir ürün yorumu var.';
$_['text_product']  = 'Ürün: %s';
$_['text_reviewer'] = 'Yorum Yapan: %s';
$_['text_rating']   = 'Verilen Oy: %s';
$_['text_review']   = 'Yapılan yorum:';