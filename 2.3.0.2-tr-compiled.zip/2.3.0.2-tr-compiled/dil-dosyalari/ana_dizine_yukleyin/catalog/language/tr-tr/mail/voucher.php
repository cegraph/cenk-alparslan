<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_subject']  = '%s tarafından hediye çeki gönderildi';
$_['text_greeting'] = 'Tebrikler, %s değerinde bir hediye çeki aldınız';
$_['text_from']     = 'Bu hediye çeki %s tarafından gönderildi';
$_['text_message']  = 'Birde mesajınız var';
$_['text_redeem']   = 'Hediye çeki ile istediğiniz ürünü satın alabilirsiniz. Hediye çekini kullanamak için bu <b>%s</b> bağlantıyı takip edin ve istediğiniz ürünü sepete ekleyiniz ve kasaya gitmenden önce alışveriş sepeti sayfasında bu hediye çekini kullanabilirsiniz.';
$_['text_footer']   = 'Lütfen herhangi bir sorunuz varsa bu e-posta mesajını yanıtlayınız.';