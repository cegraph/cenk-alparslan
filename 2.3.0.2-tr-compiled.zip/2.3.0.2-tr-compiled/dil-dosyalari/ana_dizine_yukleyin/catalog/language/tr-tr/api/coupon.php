<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_success']     = 'Başarılı: İndirim kuponu septinize başarıyla uygulandı!';

// Error
$_['error_permission'] = 'Uyarı: API erişim iznine sahip değilsiniz!';
$_['error_coupon']     = 'Uyarı: Kupon kodunuz geçersiz, süresi ya da kullanım limiti dolmuş!';