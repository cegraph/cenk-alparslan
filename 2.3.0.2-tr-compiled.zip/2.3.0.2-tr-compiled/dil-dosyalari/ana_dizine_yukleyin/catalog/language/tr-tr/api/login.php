<?php
// Text
$_['text_success'] = 'Başarılı: API oturumu başarıyla başlatıldı!';

// Error
$_['error_key']    = 'Uyarı: Yanlış API Anahtarı!';
$_['error_ip']     = 'Uyarı: IP %s adresinizden API erişimine izin verilmiyor!';