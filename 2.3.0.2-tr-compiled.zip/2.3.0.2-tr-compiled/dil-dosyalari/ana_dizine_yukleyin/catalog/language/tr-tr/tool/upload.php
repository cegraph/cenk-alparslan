<?php
// Text
$_['text_upload']    = 'Dosyanız başarıyla yüklendi!';

// Error
$_['error_filename'] = 'Dosya adı 3 ile 64 karakter arasında olmalıdır!';
$_['error_filetype'] = 'İzin verilmeyen dosya türü!';
$_['error_upload']   = 'Dosya gerekli!';