<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title'] = 'Oturum Kapatıldı';

// Text
$_['text_message']  = '<p>Ortaklık hesabınızdan çıkış yaptınız.</p>';
$_['text_account']  = 'Ortaklık Hesabım';
$_['text_logout']   = 'Oturum Kapatıldı';