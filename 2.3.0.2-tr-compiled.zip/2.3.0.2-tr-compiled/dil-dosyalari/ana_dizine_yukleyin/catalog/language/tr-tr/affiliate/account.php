<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']        = 'Ortaklık Hesabım';

// Text
$_['text_account']         = 'Ortaklık Hesabım';
$_['text_my_account']      = 'Ortaklık Hesabım';
$_['text_my_tracking']     = 'Takip Bilgilerim';
$_['text_my_transactions'] = 'İşlemlerim';
$_['text_edit']            = 'Ortaklık Bilgilerimi Düzenle';
$_['text_password']        = 'Parola Değiştir';
$_['text_payment']         = 'Ödeme Bilgilerimi Değiştir';
$_['text_tracking']        = 'Takip Kodu Oluşturma Aracı';
$_['text_transaction']     = 'İşlem Geçmişini Göster';