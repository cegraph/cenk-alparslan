<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']      = 'İşlemleriniz';

// Column
$_['column_date_added']  = 'Ekleme Tarihi';
$_['column_description'] = 'Açıklama';
$_['column_amount']      = 'Tutar (%s)';

// Text
$_['text_account']       = 'Ortaklık Hesabım';
$_['text_transaction']   = 'İşlemleriniz';
$_['text_balance']       = 'Geçerli Bakiyeniz:';
$_['text_empty']         = 'Hiç işleminiz yok!';