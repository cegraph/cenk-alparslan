<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_title']       = 'Mağazadan Teslim Al';
$_['text_description'] = 'Mağazadan Teslim Al';