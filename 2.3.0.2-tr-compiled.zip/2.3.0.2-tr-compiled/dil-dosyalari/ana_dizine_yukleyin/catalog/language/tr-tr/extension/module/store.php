<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title'] = 'Mağaza Seçiniz';

// Text
$_['text_default']  = 'Varsayılan';
$_['text_store']    = 'Ziyaret etmek istediğiniz mağazayı seçiniz.';