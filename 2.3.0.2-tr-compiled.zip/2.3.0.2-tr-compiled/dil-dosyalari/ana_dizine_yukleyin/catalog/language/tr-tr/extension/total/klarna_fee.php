<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_klarna_fee'] = 'Klarna Ücreti';