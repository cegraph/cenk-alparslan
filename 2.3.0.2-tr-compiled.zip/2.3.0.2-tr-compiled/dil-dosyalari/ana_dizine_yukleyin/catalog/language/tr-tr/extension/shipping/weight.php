<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_title']  = 'Ağırlığa Göre Kargo';
$_['text_weight'] = 'Ağırlık:';