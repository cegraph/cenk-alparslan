<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_credit']   = 'Mağaza Kredisi';
$_['text_order_id'] = 'Sipariş No: #%s';