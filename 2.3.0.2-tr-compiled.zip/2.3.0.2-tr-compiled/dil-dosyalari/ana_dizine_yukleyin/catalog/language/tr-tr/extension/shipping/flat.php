<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_title']       = 'Sabit Fiyatlı Kargo';
$_['text_description'] = 'Sabit Fiyatlı Kargo';