<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_title']       = 'Banka Havalesi/EFT';
$_['text_instruction'] = 'Banka Havalesi/EFT Talimatları';
$_['text_description'] = 'Lütfen aşağıdaki banka hesaplarına toplam tutarı yatırınız.';
$_['text_payment']     = 'Siparişinizi verdikten sonraki 5 iş günü içinde havale/eft yapmadığınız taktirde siparişiniz iptal olur.';