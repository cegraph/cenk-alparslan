<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Hesabım';

// Text
$_['text_register']    = 'Kayıt Ol';
$_['text_login']       = 'Oturum Aç';
$_['text_logout']      = 'Çıkış Yap';
$_['text_forgotten']   = 'Parolamı Unuttum';
$_['text_account']     = 'Hesabım';
$_['text_edit']        = 'Bilgilerimi Düzenle';
$_['text_password']    = 'Parola Değiştir';
$_['text_address']     = 'Adres Defterlerim';
$_['text_wishlist']    = 'Alışveriş Listem';
$_['text_order']       = 'Siparişlerim';
$_['text_download']    = 'Dosyalarım';
$_['text_reward']      = 'Puanlarım';
$_['text_return']      = 'İade Taleplerim';
$_['text_transaction'] = 'Bakiye İşlemlerim';
$_['text_newsletter']  = 'Bülten Aboneliği';
$_['text_recurring']   = 'Otomatik Ödemeler';