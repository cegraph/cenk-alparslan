<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_title']  = 'Citylink';
$_['text_weight'] = 'Ağırlık:';