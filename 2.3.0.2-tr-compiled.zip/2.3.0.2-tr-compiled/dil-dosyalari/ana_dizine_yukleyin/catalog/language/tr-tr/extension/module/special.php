<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title'] = 'Kampanyalı Ürünler';

// Text
$_['text_tax']      = 'Vergiler Hariç:';