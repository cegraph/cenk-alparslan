<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_title']       = 'Ücretsiz Kargo';
$_['text_description'] = 'Ücretsiz Kargo';