<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_title']           = 'Kredi Kartı / Banka Kartı (SagePay US)';
$_['text_credit_card']     = 'Kredi Kartı Detayları';

// Entry
$_['entry_cc_owner']       = 'Kart Sahibi';
$_['entry_cc_number']      = 'Kart Numarası';
$_['entry_cc_expire_date'] = 'Son Kullanma Tarihi';
$_['entry_cc_cvv2']        = 'Güvenlik Kodu (CVV2)';