<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_title'] = 'Kredi Kartı / Banka Kartı (2Checkout)';