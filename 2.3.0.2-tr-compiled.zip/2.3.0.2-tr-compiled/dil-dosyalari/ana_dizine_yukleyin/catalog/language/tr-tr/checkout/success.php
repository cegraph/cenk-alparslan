<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title'] = 'Siparişiniz başarıyla oluşturuldu!';

// Text
$_['text_basket']   = 'Sepetim';
$_['text_checkout'] = 'Kasaya Git';
$_['text_success']  = 'Başarılı';
$_['text_customer'] = '<p>Bizi tercih ettiğiniz için teşekkür ederiz.</p><p>Hesabınızı görüntülemek için <a href="%s">buraya</a>, sipariş geçmişiniz için <a href="%s">buraya</a> tıklayınız.</p><p>Eğer dosya içeren ürün satın aldıysanız, <a href="%s">Dosyalarım</a> sayfasına bakınız.</p><p>Herhangi bir sorunuz varsa <a href="%s">buradan</a> iletişime geçebilirsiniz.</p>';
$_['text_guest']    = '<p>Bizi tercih ettiğiniz için teşekkür ederiz.</p><p>Herhangi bir sorunuz varsa <a href="%s">buradan</a> iletişime geçebilirsiniz.</p>';