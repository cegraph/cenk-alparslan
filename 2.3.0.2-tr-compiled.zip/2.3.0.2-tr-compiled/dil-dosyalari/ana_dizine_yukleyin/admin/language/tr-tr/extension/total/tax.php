<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Vergiler';

// Text
$_['text_total']       = 'Sipariş Toplamları';
$_['text_success']     = 'Başarılı: Vergiler toplamı vergiler başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Vergi Toplamını Düzenle';

// Entry
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Vergi toplamını düzenleme iznine sahip değilsiniz!!';