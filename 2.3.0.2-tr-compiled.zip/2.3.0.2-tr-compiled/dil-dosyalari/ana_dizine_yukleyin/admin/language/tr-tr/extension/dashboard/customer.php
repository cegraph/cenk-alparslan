<?php
// Heading
$_['heading_title']    = 'Toplam Müşteri';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Toplam müşteri gösterge paneli başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Toplam Müşterileri Düzenle';
$_['text_view']        = 'Daha fazla...';

// Entry
$_['entry_width']      = 'Genişlik';
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Toplam müşteri gösterge panelini düzenleme iznine sahip değilsiniz!';