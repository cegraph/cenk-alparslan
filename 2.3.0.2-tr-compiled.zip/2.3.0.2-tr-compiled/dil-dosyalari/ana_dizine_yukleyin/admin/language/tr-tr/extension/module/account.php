<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Hesabım';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Hesabım modülü güncellendi!';
$_['text_edit']        = 'Hesabım Modülünü Düzenle';

// Entry
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: Hesabım modülünü değiştirme iznine sahip değilsiniz!';