<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Süzgeçler';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Süzgeçler modülü güncellendi!';
$_['text_edit']        = 'Süzgeç Modülünü Düzenle';

// Entry
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: Süzgeçler modülünü değiştirme iznine sahip değilsiniz!';