<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']      = 'Ücretsiz Ödeme';

// Text
$_['text_extension']     = 'Eklentiler';
$_['text_success']       = 'Başarılı: Ücretsiz Ödeme başarılı bir şekilde değiştirildi!';
$_['text_edit']          = 'Ücretsiz Ödeme Düzenle';

// Entry
$_['entry_order_status'] = 'Sipariş Durumu';
$_['entry_status']       = 'Durumu';
$_['entry_sort_order']   = 'Sıralama';

// Error
$_['error_permission']   = 'Uyarı: Ücretsiz ödeme metodunu düzenleme iznine sahip değilsiniz!';