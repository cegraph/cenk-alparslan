<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Mağaza Kredisi';
$_['text_edit']        = 'Mağaza Kredisi Düzenle';

// Text
$_['text_total']       = 'Sipariş Toplamları';
$_['text_success']     = 'Başarılı: Mağaza kredi toplamı başarılı bir şekilde değiştirildi!';

// Entry
$_['entry_status']     = 'Durum';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Mağaza kredi toplamını düzenleme iznine sahip değilsiniz!';