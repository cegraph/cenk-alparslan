<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Mağazalar';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Mağazalar modülü güncellendi!';
$_['text_edit']        = 'Mağaza Modülünü Düzenle';

// Entry
$_['entry_admin']      = 'Sadece Yöneticilere Göster';
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: Mağazalar modülünü değiştirme iznine sahip değilsiniz!';