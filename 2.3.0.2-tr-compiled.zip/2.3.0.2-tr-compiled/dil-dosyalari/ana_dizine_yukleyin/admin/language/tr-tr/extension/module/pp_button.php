<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'PayPal Express Checkout Button';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: PayPal Express Checkout Button modülü güncellendi!';
$_['text_edit']        = 'PayPal Express Checkout Modülünü Düzenle';

// Entry
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: PayPal Express Checkout Button modülünü değiştirme iznine sahip değilsiniz!';