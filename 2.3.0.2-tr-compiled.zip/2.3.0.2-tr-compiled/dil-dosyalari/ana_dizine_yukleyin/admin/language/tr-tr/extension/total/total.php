<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Toplam';

// Text
$_['text_total']       = 'Sipariş Toplamları';
$_['text_success']     = 'Başarılı: Sipariş toplamı başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Toplamı Düzenle';

// Entry
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Sipariş toplamını düzenleme iznine sahip değilsiniz!';