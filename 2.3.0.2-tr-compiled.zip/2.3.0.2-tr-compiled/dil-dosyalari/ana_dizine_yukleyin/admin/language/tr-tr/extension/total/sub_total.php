<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Ara Toplam';

// Text
$_['text_total']       = 'Sipariş Toplamları';
$_['text_success']     = 'Başarılı: Ara toplam toplamı başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Ara Toplamı Düzenle';

// Entry
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Ara toplam toplamını düzenleme iznine sahip değilsiniz!!';