<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Kargolama';

// Text
$_['text_total']       = 'Sipariş Toplamları';
$_['text_success']     = 'Başarılı: Kargo toplamı başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Kargolama Toplamını Düzenle';

// Entry
$_['entry_estimator']  = 'Kargo Hesaplaması';
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Kargo toplamını düzenleme iznine sahip değilsiniz!!';