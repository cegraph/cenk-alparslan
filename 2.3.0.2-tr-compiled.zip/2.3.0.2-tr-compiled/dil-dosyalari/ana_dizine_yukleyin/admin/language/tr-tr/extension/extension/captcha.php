<?php
// Heading
$_['heading_title']    = 'Doğrulamalar';

// Text
$_['text_success']     = 'Başarılı: Doğrulamalar başarılı bir şekilde değiştirildi!';
$_['text_list']        = 'Doğrulama Listesi';

// Column
$_['column_name']      = 'Doğrulama Adı';
$_['column_status']    = 'Durumu';
$_['column_action']    = 'Eylem';

// Error
$_['error_permission'] = 'Uyarı: Doğrulamaları düzenleme iznine sahip değilsiniz!';