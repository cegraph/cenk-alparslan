<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Google Sitemap beslemesi güncellendi!';
$_['text_edit']        = 'Google Sitemap Düzenle';

// Entry
$_['entry_status']     = 'Durumu';
$_['entry_data_feed']  = 'Feed Veri Adresi';

// Error
$_['error_permission'] = 'Uyarı: Google Sitemap düzenleme iznine sahip değilsiniz!';