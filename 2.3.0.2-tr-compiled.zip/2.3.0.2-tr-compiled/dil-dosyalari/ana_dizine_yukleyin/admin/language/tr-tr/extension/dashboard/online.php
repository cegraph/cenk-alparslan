<?php
// Heading
$_['heading_title']    = 'Çevrimiçi Olanlar';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Çevrimiçi olanlar gösterge paneli başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Çevrimiçi Olanları Düzenle';
$_['text_view']        = 'Daha fazla...';

// Entry
$_['entry_width']      = 'Genişlik';
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Çevrimiçi olanlar gösterge panelini düzenleme iznine sahip değilsiniz!';