<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Ortaklık';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Ortaklık modülü güncellendi!';
$_['text_edit']        = 'Ortaklık Modülünü Düzenle';

// Entry
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: Ortaklık modülünü değiştirme iznine sahip değilsiniz!';