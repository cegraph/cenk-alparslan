<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Kupon';
$_['text_edit']        = 'Kupon Düzenle';

// Text
$_['text_total']       = 'Sipariş Toplamları';
$_['text_success']     = 'Başarılı: Kupon Toplamı başarılı bir şekilde değiştirildi!';

// Entry
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Kupon Toplamını düzenleme iznine sahip değilsiniz!';