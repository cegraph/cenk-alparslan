<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Hediye Çeki';

// Text
$_['text_total']       = 'Sipariş Toplamı';
$_['text_success']     = 'Başarılı: Hediye çeki toplamı başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Hediye Çeki Toplamını Düzenle';

// Entry
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Hediye çeki toplamını düzenleme iznine sahip değilsiniz!';