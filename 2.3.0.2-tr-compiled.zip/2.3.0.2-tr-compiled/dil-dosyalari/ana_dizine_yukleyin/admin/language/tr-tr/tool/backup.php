<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']    = 'Yedekle &amp; Geri Yükle';

// Text
$_['text_success']     = 'Başarılı: Veritabanı başarı bir şekilde geri yüklendi!';

// Entry
$_['entry_import']     = 'İçeri Aktar';
$_['entry_export']     = 'Dışarı Aktar';

// Error
$_['error_permission'] = 'Uyarı: Yedekleme &amp; Geri Yüklemeleri düzenleme iznine sahip değilsiniz!';
$_['error_export']     = 'Uyarı: Dışarı aktarmak için en az bir tablo seçmelisiniz!';
$_['error_empty']      = 'Uyarı: Yüklediğin dosya boş!';