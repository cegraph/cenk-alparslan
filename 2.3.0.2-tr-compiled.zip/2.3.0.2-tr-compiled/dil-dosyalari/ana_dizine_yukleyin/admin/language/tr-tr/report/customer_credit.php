<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']         = 'Müşteri Kredi Raporu';

// Text
$_['text_list']             = 'Müşteri Kredi Listesi';

// Column
$_['column_customer']       = 'Müşteri Adı';
$_['column_email']          = 'E-Posta';
$_['column_customer_group'] = 'Müşteri Gurubu';
$_['column_status']         = 'Durumu';
$_['column_total']          = 'Toplam';
$_['column_action']         = 'Eylem';

// Entry
$_['entry_date_start']      = 'Başlangıç';
$_['entry_date_end']        = 'Bitiş';
$_['entry_customer']        = 'Müşteri';