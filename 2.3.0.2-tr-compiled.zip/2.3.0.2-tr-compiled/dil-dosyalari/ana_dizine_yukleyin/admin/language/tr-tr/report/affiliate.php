<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']     = 'Ortaklık Komisyon Raporu';

// Text
$_['text_list']         = 'Ortaklık Komisyon Listesi';

// Column
$_['column_affiliate']  = 'Ortaklık Adı';
$_['column_email']      = 'E-Posta';
$_['column_status']     = 'Durumu';
$_['column_commission'] = 'Komisyon';
$_['column_orders']     = 'Sipariş Sayısı';
$_['column_total']      = 'Toplam';
$_['column_action']     = 'Eylem';

// Entry
$_['entry_date_start']  = 'Başlangıç';
$_['entry_date_end']    = 'Bitiş';