<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Heading
$_['heading_title']          = 'OpenCart Türkçe';

// Text
$_['text_order']             = 'Siparişler';
$_['text_processing_status'] = 'Hazırlanıyor';
$_['text_complete_status']   = 'Tamamlandı';
$_['text_customer']          = 'Müşteriler';
$_['text_online']            = 'Çevrimiçi Olanlar';
$_['text_approval']          = 'Onay Bekliyor';
$_['text_product']           = 'Ürünler';
$_['text_stock']             = 'Tükenenler';
$_['text_review']            = 'Yorumlar';
$_['text_return']            = 'Ürün İadeleri';
$_['text_affiliate']         = 'Ortaklar';
$_['text_store']             = 'Mağazalar';
$_['text_front']             = 'Mağazaya Git';
$_['text_help']              = 'Yardım';
$_['text_homepage']          = 'OpenCart Anasayfa';
$_['text_support']           = 'Forum Destek';
$_['text_documentation']     = 'Dökümantasyon';
$_['text_logout']            = 'Çıkış Yap';
