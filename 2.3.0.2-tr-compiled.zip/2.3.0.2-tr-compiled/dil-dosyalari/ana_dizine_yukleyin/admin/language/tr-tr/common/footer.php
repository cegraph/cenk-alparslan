<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_footer']  = 'Altyapı: <a href="http://www.opencart.com">OpenCart</a> Geliştirici: <a href="http://www.opencart-tr.com" title="Opencart-TR Opencart Türkiye">Opencart-TR</a> &copy; 2009 - ' . date('Y') . ' Tüm Hakları Saklıdır.';
$_['text_version'] = 'Sürüm %s';