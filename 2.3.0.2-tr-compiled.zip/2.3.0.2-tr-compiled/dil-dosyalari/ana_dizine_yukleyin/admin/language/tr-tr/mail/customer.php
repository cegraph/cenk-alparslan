<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_approve_subject']      = '%s - Hesabınız Etkinleştirildi!';
$_['text_approve_welcome']      = '%s sitemize kayıt olduğunuz için teşekkür ederiz!';
$_['text_approve_login']        = 'Hesabınız onaylanmıştır. Aşağıdaki adres üzerinden, sitemize kayıtlı e-posta ve şifrenizi kullanarak giriş yapabilirsiniz:';
$_['text_approve_services']     = 'Giriş yaptıktan sonra, hesap bilgilerinizi düzenleyebilir veya geçmiş siparişlerinizi inceleyebilirsiniz';
$_['text_approve_thanks']       = 'Teşekkürler,';
$_['text_transaction_subject']  = '%s - Hesap Bakiyeniz';
$_['text_transaction_received'] = '%s kredi aldınız!';
$_['text_transaction_total']    = 'Şu anki toplam bakiyeniz %s.' . "\n\n" . 'Kazandığınız krediler, sonraki alışverişinizde hesabınızdan otomatik olarak düşülür.';
$_['text_reward_subject']       = '%s - Puan';
$_['text_reward_received']      = '%s Puan Kazandınız!';
$_['text_reward_total']         = 'Şu anki toplam puanınız %s.';