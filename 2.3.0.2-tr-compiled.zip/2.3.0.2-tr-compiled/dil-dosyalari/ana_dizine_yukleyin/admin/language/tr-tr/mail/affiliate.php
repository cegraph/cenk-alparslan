<?php
/* Turkceye Ceviren eka7a - http://www.opencart-tr.com */

// Text
$_['text_approve_subject']      = '%s - Ortaklık Heabınız Etkinleştirildi!';
$_['text_approve_welcome']      = '%s ortaklık programına kayıt olduğunuz için teşekkür ederiz!';
$_['text_approve_login']        = 'Ortaklık hesabınız onaylanmıştır. Aşağıdaki adres üzerinden, sitemize kayıtlı e-posta ve şifrenizi kullanarak giriş yapabilirsiniz:';
$_['text_approve_services']     = 'Oturum açtıktan sonra, takip kodu oluşturabilir, kazançlarınızı takip edebilir ve bilgilerinizi düzenleyebilirsiniz.';
$_['text_approve_thanks']       = 'Teşekküler,';
$_['text_transaction_subject']  = '%s - Ortaklık Komisyonu';
$_['text_transaction_received'] = 'Komisyon oranınıza göre kazandığınız bakiye %s dir.';
$_['text_transaction_total']    = 'Kazandığınız bakiye ile birlikte toplam bakiyeniz %s.';